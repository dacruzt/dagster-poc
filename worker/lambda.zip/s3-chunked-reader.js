"use strict";
/**
 * S3 Chunked Reader
 * Reads large files from S3 in chunks to avoid OOM errors
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ChunkedReader = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const dagster_pipes_1 = require("./dagster-pipes");
class S3ChunkedReader {
    s3Client;
    chunkSizeMB;
    constructor(region, chunkSizeMB = 10) {
        this.s3Client = new client_s3_1.S3Client({ region });
        this.chunkSizeMB = chunkSizeMB;
    }
    /**
     * Get file metadata from S3
     */
    async getFileInfo(bucket, key) {
        const command = new client_s3_1.HeadObjectCommand({ Bucket: bucket, Key: key });
        const response = await this.s3Client.send(command);
        return {
            bucket,
            key,
            size: response.ContentLength || 0,
            contentType: response.ContentType,
            lastModified: response.LastModified,
        };
    }
    /**
     * Determine optimal task size based on file size
     */
    getRecommendedTaskSize(fileSizeBytes) {
        const sizeMB = fileSizeBytes / (1024 * 1024);
        if (sizeMB < 50)
            return "lambda";
        if (sizeMB < 200)
            return "medium";
        if (sizeMB < 500)
            return "large";
        return "xlarge";
    }
    /**
     * Process file in chunks using Range requests
     */
    async processInChunks(fileInfo, processor) {
        const chunkSize = this.chunkSizeMB * 1024 * 1024;
        const totalChunks = Math.ceil(fileInfo.size / chunkSize);
        dagster_pipes_1.pipes.log(`Processing file in ${totalChunks} chunks (${this.chunkSizeMB}MB each)`);
        let bytesProcessed = 0;
        for (let i = 0; i < totalChunks; i++) {
            const startByte = i * chunkSize;
            const endByte = Math.min(startByte + chunkSize - 1, fileInfo.size - 1);
            const chunkInfo = {
                chunkIndex: i,
                totalChunks,
                startByte,
                endByte,
                size: endByte - startByte + 1,
            };
            dagster_pipes_1.pipes.reportProgress(i + 1, totalChunks, `Processing chunk ${i + 1}/${totalChunks}`);
            try {
                const data = await this.fetchChunk(fileInfo.bucket, fileInfo.key, startByte, endByte);
                await processor(data, chunkInfo);
                bytesProcessed += data.length;
            }
            catch (error) {
                dagster_pipes_1.pipes.log(`Error processing chunk ${i + 1}: ${error}`, "error");
                throw error;
            }
        }
        return { chunksProcessed: totalChunks, bytesProcessed };
    }
    /**
     * Fetch a specific byte range from S3
     */
    async fetchChunk(bucket, key, startByte, endByte) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: bucket,
            Key: key,
            Range: `bytes=${startByte}-${endByte}`,
        });
        const response = await this.s3Client.send(command);
        if (!response.Body) {
            throw new Error("Empty response body from S3");
        }
        // Convert stream to buffer
        const stream = response.Body;
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(Buffer.from(chunk));
        }
        return Buffer.concat(chunks);
    }
    /**
     * Stream file for line-by-line processing (for CSV/JSON lines)
     */
    async *streamLines(bucket, key) {
        const command = new client_s3_1.GetObjectCommand({ Bucket: bucket, Key: key });
        const response = await this.s3Client.send(command);
        if (!response.Body) {
            throw new Error("Empty response body from S3");
        }
        const stream = response.Body;
        let buffer = "";
        let lineNumber = 0;
        for await (const chunk of stream) {
            buffer += chunk.toString();
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";
            for (const line of lines) {
                lineNumber++;
                if (line.trim()) {
                    yield { line, lineNumber };
                }
            }
        }
        // Handle last line if no trailing newline
        if (buffer.trim()) {
            lineNumber++;
            yield { line: buffer, lineNumber };
        }
    }
}
exports.S3ChunkedReader = S3ChunkedReader;
