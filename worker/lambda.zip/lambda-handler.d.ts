/**
 * Lambda Handler - Entry point for AWS Lambda execution.
 * Reuses the same FileProcessor as the Fargate container.
 *
 * Invoked by dagster_ts/src/lambda-cli.ts via AWS SDK InvokeCommand.
 * Logs go to CloudWatch automatically via console.log/console.error.
 */
import { ProcessingResult } from "./file-processor";
export interface LambdaEvent {
    s3Bucket: string;
    s3Key: string;
    region?: string;
    dynamoTable: string;
    dagsterRunId?: string;
    chunkSizeMB?: number;
}
export interface LambdaResponse {
    statusCode: number;
    body: ProcessingResult;
}
export declare function handler(event: LambdaEvent): Promise<LambdaResponse>;
