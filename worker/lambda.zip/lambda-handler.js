"use strict";
/**
 * Lambda Handler - Entry point for AWS Lambda execution.
 * Reuses the same FileProcessor as the Fargate container.
 *
 * Invoked by dagster_ts/src/lambda-cli.ts via AWS SDK InvokeCommand.
 * Logs go to CloudWatch automatically via console.log/console.error.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const dagster_pipes_1 = require("./dagster-pipes");
const file_processor_1 = require("./file-processor");
async function handler(event) {
    dagster_pipes_1.pipes.log("=== Lambda Worker Starting ===");
    // Validate required fields
    if (!event.s3Bucket || !event.s3Key) {
        const error = "Missing required fields: s3Bucket, s3Key";
        dagster_pipes_1.pipes.log(error, "error");
        return {
            statusCode: 400,
            body: {
                success: false,
                rowCount: 0,
                bytesProcessed: 0,
                chunksProcessed: 0,
                durationMs: 0,
                error,
            },
        };
    }
    if (!event.dynamoTable) {
        const error = "Missing required field: dynamoTable";
        dagster_pipes_1.pipes.log(error, "error");
        return {
            statusCode: 400,
            body: {
                success: false,
                rowCount: 0,
                bytesProcessed: 0,
                chunksProcessed: 0,
                durationMs: 0,
                error,
            },
        };
    }
    const config = {
        bucket: event.s3Bucket,
        key: event.s3Key,
        region: event.region || process.env.AWS_REGION || "us-east-1",
        dynamoTable: event.dynamoTable,
        chunkSizeMB: event.chunkSizeMB || 10,
        dagsterRunId: event.dagsterRunId,
    };
    dagster_pipes_1.pipes.log(`Configuration:`, "info");
    dagster_pipes_1.pipes.log(`  Bucket: ${config.bucket}`, "info");
    dagster_pipes_1.pipes.log(`  Key: ${config.key}`, "info");
    dagster_pipes_1.pipes.log(`  Region: ${config.region}`, "info");
    dagster_pipes_1.pipes.log(`  Chunk Size: ${config.chunkSizeMB} MB`, "info");
    dagster_pipes_1.pipes.log(`  Dagster Run ID: ${config.dagsterRunId || "N/A"}`, "info");
    dagster_pipes_1.pipes.log(`  Execution Type: Lambda`, "info");
    // Set TASK_SIZE env var so FileProcessor logs the correct value
    process.env.TASK_SIZE = "lambda";
    const processor = new file_processor_1.FileProcessor(config);
    const result = await processor.process(config);
    dagster_pipes_1.pipes.log("=== Lambda Worker Finished ===");
    dagster_pipes_1.pipes.log(`Success: ${result.success}`);
    dagster_pipes_1.pipes.log(`Rows processed: ${result.rowCount.toLocaleString()}`);
    dagster_pipes_1.pipes.log(`Bytes processed: ${result.bytesProcessed.toLocaleString()}`);
    dagster_pipes_1.pipes.log(`Duration: ${result.durationMs}ms`);
    return {
        statusCode: result.success ? 200 : 500,
        body: result,
    };
}
