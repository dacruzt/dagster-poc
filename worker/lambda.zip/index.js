"use strict";
/**
 * Dagster Worker - TypeScript (Fargate entry point)
 * Processes files from S3 in chunks with Dagster Pipes integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
const dagster_pipes_1 = require("./dagster-pipes");
const file_processor_1 = require("./file-processor");
/**
 * Main entry point (Fargate container)
 */
async function main() {
    dagster_pipes_1.pipes.log("=== Dagster Worker Starting ===");
    // Get configuration from environment
    const config = {
        bucket: process.env.S3_BUCKET || "",
        key: process.env.S3_KEY || "",
        region: process.env.AWS_REGION || "us-east-1",
        dynamoTable: process.env.DYNAMO_TABLE || "",
        chunkSizeMB: parseInt(process.env.CHUNK_SIZE_MB || "10", 10),
        dagsterRunId: process.env.DAGSTER_RUN_ID,
    };
    // Validate configuration
    if (!config.bucket || !config.key) {
        dagster_pipes_1.pipes.log("Missing required environment variables: S3_BUCKET, S3_KEY", "error");
        dagster_pipes_1.pipes.reportFailure("Missing required environment variables");
        process.exit(1);
    }
    if (!config.dynamoTable) {
        dagster_pipes_1.pipes.log("Missing DYNAMO_TABLE environment variable", "error");
        dagster_pipes_1.pipes.reportFailure("Missing DYNAMO_TABLE environment variable");
        process.exit(1);
    }
    dagster_pipes_1.pipes.log(`Configuration:`, "info");
    dagster_pipes_1.pipes.log(`  Bucket: ${config.bucket}`, "info");
    dagster_pipes_1.pipes.log(`  Key: ${config.key}`, "info");
    dagster_pipes_1.pipes.log(`  Region: ${config.region}`, "info");
    dagster_pipes_1.pipes.log(`  Chunk Size: ${config.chunkSizeMB} MB`, "info");
    dagster_pipes_1.pipes.log(`  Dagster Run ID: ${config.dagsterRunId || "N/A"}`, "info");
    // Process file
    const processor = new file_processor_1.FileProcessor(config);
    const result = await processor.process(config);
    dagster_pipes_1.pipes.log("=== Dagster Worker Finished ===");
    dagster_pipes_1.pipes.log(`Success: ${result.success}`);
    dagster_pipes_1.pipes.log(`Rows processed: ${result.rowCount.toLocaleString()}`);
    dagster_pipes_1.pipes.log(`Bytes processed: ${result.bytesProcessed.toLocaleString()}`);
    dagster_pipes_1.pipes.log(`Duration: ${result.durationMs}ms`);
    // Exit with appropriate code
    process.exit(result.success ? 0 : 1);
}
// Run
main().catch((error) => {
    dagster_pipes_1.pipes.log(`Unhandled error: ${error}`, "error");
    dagster_pipes_1.pipes.reportFailure(error);
    process.exit(1);
});
