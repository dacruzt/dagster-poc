"use strict";
/**
 * FileProcessor - Shared module for processing S3 files in chunks.
 * Used by both the Fargate container (index.ts) and Lambda handler (lambda-handler.ts).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileProcessor = void 0;
const dagster_pipes_1 = require("./dagster-pipes");
const s3_chunked_reader_1 = require("./s3-chunked-reader");
const dynamo_state_1 = require("./dynamo-state");
const column_validator_1 = require("./column-validator");
class FileProcessor {
    s3Reader;
    stateManager;
    rowCount = 0;
    constructor(config) {
        this.s3Reader = new s3_chunked_reader_1.S3ChunkedReader(config.region, config.chunkSizeMB);
        this.stateManager = new dynamo_state_1.DynamoStateManager(config.region, config.dynamoTable);
    }
    /**
     * Main processing entry point
     */
    async process(config) {
        const startTime = Date.now();
        let state = null;
        try {
            // 1. Get file info
            dagster_pipes_1.pipes.log(`Fetching file info: s3://${config.bucket}/${config.key}`);
            const fileInfo = await this.s3Reader.getFileInfo(config.bucket, config.key);
            dagster_pipes_1.pipes.log(`File size: ${this.formatBytes(fileInfo.size)}`);
            dagster_pipes_1.pipes.log(`Content type: ${fileInfo.contentType || "unknown"}`);
            // 2. Determine task size and validate
            const recommendedSize = this.s3Reader.getRecommendedTaskSize(fileInfo.size);
            const currentSize = process.env.TASK_SIZE || "lambda";
            if (recommendedSize !== currentSize) {
                dagster_pipes_1.pipes.log(`Warning: Current task size (${currentSize}) may not be optimal for file size. Recommended: ${recommendedSize}`, "warning");
            }
            // 3. Create state record
            state = await this.stateManager.createIngestState(config.bucket, config.key, fileInfo.size, config.dagsterRunId, currentSize);
            // 4. Validate file structure
            await this.stateManager.updateStatus(state.pk, state.sk, "VALIDATING");
            dagster_pipes_1.pipes.log("Validating file structure...");
            const schema = (0, column_validator_1.findSchema)(config.key);
            if (schema.requiredColumns.length > 0) {
                dagster_pipes_1.pipes.log(`Schema matched: ${schema.requiredColumns.length} required columns`);
                const validation = await this.validateFile(fileInfo, schema);
                if (!validation.valid) {
                    const errorMsg = `Invalid file format: ${validation.errors.join("; ")}`;
                    throw new Error(errorMsg);
                }
                dagster_pipes_1.pipes.log("File structure validated successfully");
            }
            else {
                dagster_pipes_1.pipes.log("No schema matched, skipping validation");
            }
            // 5. Update status to processing
            await this.stateManager.updateStatus(state.pk, state.sk, "PROCESSING");
            // 6. Process file in chunks
            dagster_pipes_1.pipes.log("Starting chunked processing...");
            const result = await this.processFileInChunks(fileInfo, state);
            // 6. Mark as completed
            await this.stateManager.markCompleted(state.pk, state.sk, this.rowCount, {
                bytesProcessed: result.bytesProcessed,
                chunksProcessed: result.chunksProcessed,
                durationMs: Date.now() - startTime,
            });
            // 7. Report success to Dagster
            dagster_pipes_1.pipes.reportAssetMaterialization(`${config.bucket}/${config.key}`, {
                row_count: this.rowCount,
                bytes_processed: result.bytesProcessed,
                chunks_processed: result.chunksProcessed,
                file_size: fileInfo.size,
                task_size: currentSize,
            });
            dagster_pipes_1.pipes.reportSuccess({
                row_count: this.rowCount,
                bytes_processed: result.bytesProcessed,
                duration_ms: Date.now() - startTime,
            });
            return {
                success: true,
                rowCount: this.rowCount,
                bytesProcessed: result.bytesProcessed,
                chunksProcessed: result.chunksProcessed,
                durationMs: Date.now() - startTime,
            };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            dagster_pipes_1.pipes.log(`Processing failed: ${errorMessage}`, "error");
            // Update state to failed
            if (state) {
                await this.stateManager.markFailed(state.pk, state.sk, errorMessage);
            }
            // Report failure to Dagster
            dagster_pipes_1.pipes.reportFailure(error instanceof Error ? error : new Error(errorMessage), {
                row_count: this.rowCount,
                duration_ms: Date.now() - startTime,
            });
            return {
                success: false,
                rowCount: this.rowCount,
                bytesProcessed: 0,
                chunksProcessed: 0,
                durationMs: Date.now() - startTime,
                error: errorMessage,
            };
        }
    }
    /**
     * Process file chunks
     */
    async processFileInChunks(fileInfo, state) {
        const contentType = fileInfo.contentType?.toLowerCase() || "";
        // Determine processing strategy based on content type
        if (contentType.includes("csv") || fileInfo.key.endsWith(".csv")) {
            return this.processCsv(fileInfo, state);
        }
        else if (contentType.includes("json") || fileInfo.key.endsWith(".json")) {
            return this.processJson(fileInfo, state);
        }
        else {
            // Generic binary processing
            return this.processBinary(fileInfo, state);
        }
    }
    /**
     * Validate file structure against its schema.
     * Reads only the header + first data row (CSV) or first record (JSON).
     */
    async validateFile(fileInfo, schema) {
        const contentType = fileInfo.contentType?.toLowerCase() || "";
        const isCsv = contentType.includes("csv") || fileInfo.key.endsWith(".csv");
        const isJson = contentType.includes("json") || fileInfo.key.endsWith(".json");
        if (isCsv) {
            let headers = [];
            let firstRow = {};
            for await (const { line, lineNumber } of this.s3Reader.streamLines(fileInfo.bucket, fileInfo.key)) {
                if (lineNumber === 1) {
                    headers = this.parseCsvLine(line);
                }
                else if (lineNumber === 2) {
                    const values = this.parseCsvLine(line);
                    for (let i = 0; i < headers.length; i++) {
                        firstRow[headers[i]] = values[i] || "";
                    }
                    break;
                }
            }
            if (headers.length === 0) {
                return { valid: false, errors: ["CSV file is empty (no headers found)"] };
            }
            dagster_pipes_1.pipes.log(`CSV headers: ${headers.join(", ")}`);
            return (0, column_validator_1.validateCsvColumns)(headers, firstRow, schema);
        }
        if (isJson) {
            let entireContent = "";
            for await (const { line } of this.s3Reader.streamLines(fileInfo.bucket, fileInfo.key)) {
                entireContent += line + "\n";
            }
            let firstRecord = null;
            try {
                const parsed = JSON.parse(entireContent);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    firstRecord = parsed[0];
                }
                else if (!Array.isArray(parsed)) {
                    firstRecord = parsed;
                }
            }
            catch {
                // Try JSONL - first line
                const firstLine = entireContent.split("\n").find((l) => l.trim());
                if (firstLine) {
                    try {
                        firstRecord = JSON.parse(firstLine);
                    }
                    catch {
                        return { valid: false, errors: ["Cannot parse JSON file"] };
                    }
                }
            }
            if (!firstRecord) {
                return { valid: false, errors: ["JSON file is empty (no records found)"] };
            }
            return (0, column_validator_1.validateJsonFields)(firstRecord, schema);
        }
        // Binary files: skip validation
        return { valid: true, errors: [] };
    }
    /**
     * Process CSV file line by line
     */
    async processCsv(fileInfo, state) {
        dagster_pipes_1.pipes.log("Processing as CSV file");
        let bytesProcessed = 0;
        let isHeader = true;
        let headers = [];
        const batchSize = 1000;
        let batch = [];
        for await (const { line, lineNumber } of this.s3Reader.streamLines(fileInfo.bucket, fileInfo.key)) {
            bytesProcessed += Buffer.byteLength(line, "utf-8");
            if (isHeader) {
                headers = this.parseCsvLine(line);
                isHeader = false;
                continue;
            }
            const values = this.parseCsvLine(line);
            const row = {};
            for (let i = 0; i < headers.length; i++) {
                row[headers[i]] = values[i] || "";
            }
            batch.push(row);
            this.rowCount++;
            // Process batch
            if (batch.length >= batchSize) {
                await this.processBatch(batch);
                batch = [];
                // Update progress
                if (this.rowCount % 10000 === 0) {
                    dagster_pipes_1.pipes.reportProgress(bytesProcessed, fileInfo.size, `Processed ${this.rowCount.toLocaleString()} rows`);
                    await this.stateManager.updateProgress(state.pk, state.sk, Math.floor(bytesProcessed / (1024 * 1024)), Math.ceil(fileInfo.size / (1024 * 1024)), this.rowCount);
                }
            }
        }
        // Process remaining batch
        if (batch.length > 0) {
            await this.processBatch(batch);
        }
        return { bytesProcessed, chunksProcessed: 1 };
    }
    /**
     * Process JSON file (JSON lines or array)
     */
    async processJson(fileInfo, state) {
        dagster_pipes_1.pipes.log("Processing as JSON file");
        let bytesProcessed = 0;
        const batchSize = 1000;
        let batch = [];
        let entireContent = "";
        // First, try to determine if this is a JSON array or JSONL
        for await (const { line } of this.s3Reader.streamLines(fileInfo.bucket, fileInfo.key)) {
            entireContent += line + "\n";
        }
        bytesProcessed = Buffer.byteLength(entireContent, "utf-8");
        // Try parsing as JSON array first
        try {
            const parsed = JSON.parse(entireContent);
            if (Array.isArray(parsed)) {
                dagster_pipes_1.pipes.log(`Detected JSON array format with ${parsed.length} items`);
                // Process array items
                for (const record of parsed) {
                    batch.push(record);
                    this.rowCount++;
                    if (batch.length >= batchSize) {
                        await this.processBatch(batch);
                        batch = [];
                        if (this.rowCount % 10000 === 0) {
                            dagster_pipes_1.pipes.reportProgress(this.rowCount, parsed.length, `Processed ${this.rowCount.toLocaleString()} records`);
                            await this.stateManager.updateProgress(state.pk, state.sk, this.rowCount, parsed.length, this.rowCount);
                        }
                    }
                }
            }
            else {
                // Single JSON object
                dagster_pipes_1.pipes.log("Detected single JSON object");
                batch.push(parsed);
                this.rowCount++;
            }
        }
        catch {
            // Not a JSON array, try JSONL format
            dagster_pipes_1.pipes.log("Processing as JSON Lines format");
            const lines = entireContent.split("\n");
            for (const line of lines) {
                const trimmedLine = line.trim();
                if (!trimmedLine)
                    continue;
                try {
                    const record = JSON.parse(trimmedLine);
                    batch.push(record);
                    this.rowCount++;
                    if (batch.length >= batchSize) {
                        await this.processBatch(batch);
                        batch = [];
                        if (this.rowCount % 10000 === 0) {
                            dagster_pipes_1.pipes.reportProgress(this.rowCount, lines.length, `Processed ${this.rowCount.toLocaleString()} records`);
                            await this.stateManager.updateProgress(state.pk, state.sk, this.rowCount, lines.length, this.rowCount);
                        }
                    }
                }
                catch {
                    // Skip invalid JSON lines silently for JSONL format
                }
            }
        }
        if (batch.length > 0) {
            await this.processBatch(batch);
        }
        return { bytesProcessed, chunksProcessed: 1 };
    }
    /**
     * Process binary file in chunks
     */
    async processBinary(fileInfo, state) {
        dagster_pipes_1.pipes.log("Processing as binary file");
        const result = await this.s3Reader.processInChunks(fileInfo, async (data, chunkInfo) => {
            // Example: compute checksum, transform data, etc.
            this.rowCount += data.length;
            await this.stateManager.updateProgress(state.pk, state.sk, chunkInfo.chunkIndex + 1, chunkInfo.totalChunks, this.rowCount);
            // Simulate some processing
            await this.processChunk(data, chunkInfo);
        });
        return result;
    }
    /**
     * Process a batch of records
     */
    async processBatch(batch) {
        // Implement your transformation logic here
        // Example: validate, transform, write to another location
        dagster_pipes_1.pipes.log(`Processing batch of ${batch.length} records`);
        // Simulate processing time
        await new Promise((resolve) => setTimeout(resolve, 10));
    }
    /**
     * Process a binary chunk
     */
    async processChunk(data, chunkInfo) {
        // Implement your chunk processing logic here
        dagster_pipes_1.pipes.log(`Processing chunk ${chunkInfo.chunkIndex + 1}/${chunkInfo.totalChunks} (${this.formatBytes(data.length)})`);
        // Simulate processing time
        await new Promise((resolve) => setTimeout(resolve, 100));
    }
    /**
     * Simple CSV line parser
     */
    parseCsvLine(line) {
        const result = [];
        let current = "";
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            if (char === '"') {
                if (inQuotes && line[i + 1] === '"') {
                    current += '"';
                    i++;
                }
                else {
                    inQuotes = !inQuotes;
                }
            }
            else if (char === "," && !inQuotes) {
                result.push(current.trim());
                current = "";
            }
            else {
                current += char;
            }
        }
        result.push(current.trim());
        return result;
    }
    /**
     * Format bytes to human readable
     */
    formatBytes(bytes) {
        if (bytes === 0)
            return "0 Bytes";
        const k = 1024;
        const sizes = ["Bytes", "KB", "MB", "GB"];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
    }
}
exports.FileProcessor = FileProcessor;
