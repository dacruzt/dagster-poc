/**
 * S3 Chunked Reader
 * Reads large files from S3 in chunks to avoid OOM errors
 */
export interface S3FileInfo {
    bucket: string;
    key: string;
    size: number;
    contentType?: string;
    lastModified?: Date;
}
export interface ChunkInfo {
    chunkIndex: number;
    totalChunks: number;
    startByte: number;
    endByte: number;
    size: number;
}
export type ChunkProcessor = (data: Buffer, chunkInfo: ChunkInfo) => Promise<void>;
export declare class S3ChunkedReader {
    private readonly s3Client;
    private readonly chunkSizeMB;
    constructor(region: string, chunkSizeMB?: number);
    /**
     * Get file metadata from S3
     */
    getFileInfo(bucket: string, key: string): Promise<S3FileInfo>;
    /**
     * Determine optimal task size based on file size
     */
    getRecommendedTaskSize(fileSizeBytes: number): string;
    /**
     * Process file in chunks using Range requests
     */
    processInChunks(fileInfo: S3FileInfo, processor: ChunkProcessor): Promise<{
        chunksProcessed: number;
        bytesProcessed: number;
    }>;
    /**
     * Fetch a specific byte range from S3
     */
    private fetchChunk;
    /**
     * Stream file for line-by-line processing (for CSV/JSON lines)
     */
    streamLines(bucket: string, key: string): AsyncGenerator<{
        line: string;
        lineNumber: number;
    }>;
}
