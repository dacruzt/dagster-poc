/**
 * DynamoDB State Manager
 * Manages ingest state for tracking file processing
 */
export type IngestStatus = "PENDING" | "VALIDATING" | "PROCESSING" | "COMPLETED" | "FAILED";
export interface IngestState {
    pk: string;
    sk: string;
    bucket: string;
    key: string;
    status: IngestStatus;
    fileSize: number;
    rowCount?: number;
    chunksProcessed?: number;
    totalChunks?: number;
    errorMessage?: string;
    startedAt: string;
    completedAt?: string;
    dagsterRunId?: string;
    taskSize?: string;
    metadata?: Record<string, unknown>;
    ttl?: number;
}
export declare class DynamoStateManager {
    private readonly docClient;
    private readonly tableName;
    constructor(region: string, tableName: string);
    /**
     * Create a new ingest state record
     */
    createIngestState(bucket: string, key: string, fileSize: number, dagsterRunId?: string, taskSize?: string): Promise<IngestState>;
    /**
     * Update the status of an ingest
     */
    updateStatus(pk: string, sk: string, status: IngestStatus, updates?: Partial<IngestState>): Promise<void>;
    /**
     * Update processing progress
     */
    updateProgress(pk: string, sk: string, chunksProcessed: number, totalChunks: number, rowCount?: number): Promise<void>;
    /**
     * Mark ingest as completed
     */
    markCompleted(pk: string, sk: string, rowCount: number, metadata?: Record<string, unknown>): Promise<void>;
    /**
     * Mark ingest as failed
     */
    markFailed(pk: string, sk: string, errorMessage: string): Promise<void>;
    /**
     * Get the latest state for a file
     */
    getLatestState(bucket: string, key: string): Promise<IngestState | null>;
    /**
     * Get all states for a file (history)
     */
    getStateHistory(bucket: string, key: string): Promise<IngestState[]>;
}
