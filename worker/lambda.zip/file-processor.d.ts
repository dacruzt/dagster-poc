/**
 * FileProcessor - Shared module for processing S3 files in chunks.
 * Used by both the Fargate container (index.ts) and Lambda handler (lambda-handler.ts).
 */
export interface WorkerConfig {
    bucket: string;
    key: string;
    region: string;
    dynamoTable: string;
    chunkSizeMB: number;
    dagsterRunId?: string;
}
export interface ProcessingResult {
    success: boolean;
    rowCount: number;
    bytesProcessed: number;
    chunksProcessed: number;
    durationMs: number;
    error?: string;
}
export declare class FileProcessor {
    private readonly s3Reader;
    private readonly stateManager;
    private rowCount;
    constructor(config: WorkerConfig);
    /**
     * Main processing entry point
     */
    process(config: WorkerConfig): Promise<ProcessingResult>;
    /**
     * Process file chunks
     */
    private processFileInChunks;
    /**
     * Validate file structure against its schema.
     * Reads only the header + first data row (CSV) or first record (JSON).
     */
    private validateFile;
    /**
     * Process CSV file line by line
     */
    private processCsv;
    /**
     * Process JSON file (JSON lines or array)
     */
    private processJson;
    /**
     * Process binary file in chunks
     */
    private processBinary;
    /**
     * Process a batch of records
     */
    private processBatch;
    /**
     * Process a binary chunk
     */
    private processChunk;
    /**
     * Simple CSV line parser
     */
    private parseCsvLine;
    /**
     * Format bytes to human readable
     */
    private formatBytes;
}
