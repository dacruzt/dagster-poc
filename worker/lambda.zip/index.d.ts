/**
 * Dagster Worker - TypeScript (Fargate entry point)
 * Processes files from S3 in chunks with Dagster Pipes integration
 */
export {};
