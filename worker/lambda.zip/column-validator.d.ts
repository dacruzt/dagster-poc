/**
 * Column Validator - Validates file structure against configurable schemas.
 * Schemas are defined in schemas.json and matched by filename pattern.
 */
export interface ColumnDef {
    name: string;
    type: "string" | "date" | "number";
}
export interface FileSchema {
    pattern: string;
    requiredColumns: ColumnDef[];
}
export interface ValidationResult {
    valid: boolean;
    errors: string[];
}
/**
 * Find the schema that matches the given S3 key.
 * Returns defaultSchema if no pattern matches.
 */
export declare function findSchema(s3Key: string): {
    requiredColumns: ColumnDef[];
};
/**
 * Validate CSV headers and first row against a schema.
 */
export declare function validateCsvColumns(headers: string[], firstRow: Record<string, string>, schema: {
    requiredColumns: ColumnDef[];
}): ValidationResult;
/**
 * Validate a JSON record against a schema.
 */
export declare function validateJsonFields(record: unknown, schema: {
    requiredColumns: ColumnDef[];
}): ValidationResult;
