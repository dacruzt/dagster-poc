/**
 * Dagster Pipes Protocol Implementation for TypeScript
 * Streams logs and metadata to Dagster UI via stdout
 *
 * The protocol uses special prefixes that Dagster recognizes:
 * - Regular logs go to CloudWatch and are picked up by PipesCloudWatchMessageReader
 * - Structured messages use __DAGSTER_PIPES_MESSAGES prefix
 */
export interface PipesContext {
    runId: string;
    jobName: string;
    extras: Record<string, unknown>;
}
export interface PipesMessage {
    __dagster_pipes_version: string;
    method: string;
    params: Record<string, unknown>;
}
export declare class DagsterPipes {
    private context;
    private readonly pipesVersion;
    private startTime;
    constructor();
    private initContext;
    /**
     * Check if running within Dagster Pipes context
     */
    isRunningInPipes(): boolean;
    /**
     * Get extra parameters passed from Dagster
     */
    getExtras(): Record<string, unknown>;
    /**
     * Get elapsed time in seconds
     */
    getElapsedSeconds(): number;
    /**
     * Log a message - appears in CloudWatch and Dagster UI
     */
    log(message: string, level?: "info" | "warning" | "error" | "debug"): void;
    /**
     * Log a section header for better visibility
     */
    logSection(title: string): void;
    /**
     * Report progress with a progress bar
     */
    reportProgress(current: number, total: number, label?: string): void;
    /**
     * Report an asset materialization with metadata
     */
    reportAssetMaterialization(assetKey: string, metadata: Record<string, unknown>): void;
    /**
     * Report custom metadata (row counts, file sizes, etc.)
     */
    reportMetadata(metadata: Record<string, unknown>): void;
    /**
     * Report successful completion
     */
    reportSuccess(metadata?: Record<string, unknown>): void;
    /**
     * Report failure
     */
    reportFailure(error: Error | string, metadata?: Record<string, unknown>): void;
    private formatMetadata;
    private sendMessage;
}
export declare const pipes: DagsterPipes;
