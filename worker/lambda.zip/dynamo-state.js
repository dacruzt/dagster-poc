"use strict";
/**
 * DynamoDB State Manager
 * Manages ingest state for tracking file processing
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoStateManager = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dagster_pipes_1 = require("./dagster-pipes");
class DynamoStateManager {
    docClient;
    tableName;
    constructor(region, tableName) {
        const client = new client_dynamodb_1.DynamoDBClient({ region });
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
        this.tableName = tableName;
    }
    /**
     * Create a new ingest state record
     */
    async createIngestState(bucket, key, fileSize, dagsterRunId, taskSize) {
        const now = new Date().toISOString();
        const ttl = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60; // 30 days
        const state = {
            pk: `FILE#${bucket}#${key}`,
            sk: `STATE#${now}`,
            bucket,
            key,
            status: "PENDING",
            fileSize,
            startedAt: now,
            dagsterRunId,
            taskSize,
            ttl,
        };
        await this.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: state,
        }));
        dagster_pipes_1.pipes.log(`Created ingest state for ${bucket}/${key}`);
        return state;
    }
    /**
     * Update the status of an ingest
     */
    async updateStatus(pk, sk, status, updates) {
        const updateExpressions = ["#status = :status"];
        const expressionNames = { "#status": "status" };
        const expressionValues = { ":status": status };
        if (updates) {
            for (const [key, value] of Object.entries(updates)) {
                if (key !== "pk" && key !== "sk" && key !== "status") {
                    updateExpressions.push(`#${key} = :${key}`);
                    expressionNames[`#${key}`] = key;
                    expressionValues[`:${key}`] = value;
                }
            }
        }
        if (status === "COMPLETED" || status === "FAILED") {
            updateExpressions.push("#completedAt = :completedAt");
            expressionNames["#completedAt"] = "completedAt";
            expressionValues[":completedAt"] = new Date().toISOString();
        }
        await this.docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: { pk, sk },
            UpdateExpression: `SET ${updateExpressions.join(", ")}`,
            ExpressionAttributeNames: expressionNames,
            ExpressionAttributeValues: expressionValues,
        }));
        dagster_pipes_1.pipes.log(`Updated status to ${status} for ${pk}`);
    }
    /**
     * Update processing progress
     */
    async updateProgress(pk, sk, chunksProcessed, totalChunks, rowCount) {
        const updates = {
            chunksProcessed,
            totalChunks,
        };
        if (rowCount !== undefined) {
            updates.rowCount = rowCount;
        }
        await this.updateStatus(pk, sk, "PROCESSING", updates);
    }
    /**
     * Mark ingest as completed
     */
    async markCompleted(pk, sk, rowCount, metadata) {
        await this.updateStatus(pk, sk, "COMPLETED", {
            rowCount,
            metadata,
        });
    }
    /**
     * Mark ingest as failed
     */
    async markFailed(pk, sk, errorMessage) {
        await this.updateStatus(pk, sk, "FAILED", { errorMessage });
    }
    /**
     * Get the latest state for a file
     */
    async getLatestState(bucket, key) {
        const result = await this.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: "pk = :pk",
            ExpressionAttributeValues: {
                ":pk": `FILE#${bucket}#${key}`,
            },
            ScanIndexForward: false, // Latest first
            Limit: 1,
        }));
        return result.Items?.[0] || null;
    }
    /**
     * Get all states for a file (history)
     */
    async getStateHistory(bucket, key) {
        const result = await this.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: "pk = :pk",
            ExpressionAttributeValues: {
                ":pk": `FILE#${bucket}#${key}`,
            },
            ScanIndexForward: false,
        }));
        return result.Items || [];
    }
}
exports.DynamoStateManager = DynamoStateManager;
